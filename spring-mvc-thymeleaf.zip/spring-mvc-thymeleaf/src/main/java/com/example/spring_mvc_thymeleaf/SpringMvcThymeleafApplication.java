package com.example.spring_mvc_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcThymeleafApplication.class, args);
	}

}
