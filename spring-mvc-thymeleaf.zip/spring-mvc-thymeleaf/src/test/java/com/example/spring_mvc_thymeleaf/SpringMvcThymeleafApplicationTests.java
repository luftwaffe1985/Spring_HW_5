package com.example.spring_mvc_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
